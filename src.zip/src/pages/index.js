import '../pages/index.css';
import { Card } from "../components/Card.js";
import { PopupWithImage } from "../components/PopupWithImage.js";
import { PopupWithForm } from "../components/PopupWithForm.js";
import {initialCards, validation} from "../components/constans.js";
import FormValidator from "../components/FormValidator.js";
import { 
    cardListSelector,
    profileOpenBtn,
    buttonPhoto,
    bigPhotoSelector,
    profilePopupSelector,
    cardPopupSelector,
    bigPhotoConfig,
    popupConfig,
    formConfig,
    profileConfig,
    avatarPopupSelector,
    avatarPhotoBtn
    
    } from "../components/constans.js";
import { Section } from "../components/Section.js";
import { UserInfo } from "../components/UserInfo.js";
import { Api } from '../components/Api';

const api = new Api({
    url: 'https://nomoreparties.co/v1/cohort-50',
    headers: {
        authorization: "b319dc1f-190e-4d9d-9328-6f9f6661ac0d", 
        "Content-Type": "application/json", 
    }
})

Promise.all([api.getUserInfo(), api.getInitialCard()])
.then(([userData, cards]) => {
    userInfo.setUserAvatar(userData.link);
    userInfo.setUserInfo(userData.name, userData.about);
    cardContainer.renderedItems(cards.reverse());
})
.catch(err => {
    console.log(err);
});

function createCard({name, link}) {
    const card = new Card (name, link, '#photo-template', imagePopup.open);
    const cardElement = card.generateCard();
    return cardElement;
};

const cardContainer = new Section({
    renderer: (item) => {
        const card = createCard(item);
        cardContainer.addItem(card);
    }
}, cardListSelector);

const imagePopup = new PopupWithImage(bigPhotoSelector, popupConfig, bigPhotoConfig);
imagePopup.setEventListeners();

const userInfo = new UserInfo (profileConfig);

const formValidators = {};

Array.from(document.forms).forEach((formElement) => {
    formValidators[formElement.name] = new FormValidator(validation, formElement);
    formValidators[formElement.name].enableValidation();
})

const handleCardSubmit = (item) => {
    cardContainer.addItem(createCard(item));
}
        
const newCardPopup = new PopupWithForm(
    cardPopupSelector,
    popupConfig, 
    formConfig, 
    handleCardSubmit, 
    formValidators["photo"].cleanUpForm, 
    'picture-input-',
    );
        
newCardPopup.setEventListeners();
        
buttonPhoto.addEventListener("click", newCardPopup.open);

const handleProfileSubmit = (data) => {
    userInfo.setUserInfo(data);
}

const editProfilePopup = new PopupWithForm(
    profilePopupSelector, 
    popupConfig, 
    formConfig, 
    handleProfileSubmit, 
    formValidators["profile"].cleanUpForm, 
    'profile-input-', 
    userInfo.getUserInfo,
);

editProfilePopup.setEventListeners();

profileOpenBtn.addEventListener("click", editProfilePopup.open)

const handleAvatarSubmit = (link) => {
    userInfo.setUserAvatar(link);
}

const newAvatarPopup = new PopupWithForm(
    avatarPopupSelector,
    popupConfig,
    formConfig,
    handleAvatarSubmit,
    formValidators["avatar"].cleanUpForm, 
    'userpic-input-', 
    userInfo.getUserInfo
)

newAvatarPopup.setEventListeners();

avatarPhotoBtn.addEventListener("click", newAvatarPopup.open)